# Cognitive Services Windows Common

This repository contains code shared between different Windows SDK and samples
